package com.example.login_cs360jk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {
    EditText username;
    EditText password;
    EditText new_register_here;
    EditText forgot_password;
    Button btn_submit;
    DBHelper MyDB;
    private Object Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        new_register_here = (EditText) findViewById(R.id.new_register_here);

        MyDB = new DBHelper(this);

        Button = findViewById(R.id.btn_submit);
        Button.notify(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String new_register_here = new_register_here.getText().toString();

                if(new_register_here.equals(""))
                {
                    Toast.makeText(LoginPage.this, "Enter username", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean result = MyDB.new_register_here(new_register_here);
                    if(result == false)
                    {
                        Toast.makeText(LoginPage.this, "User does not exists.\n Kindly Register", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), RegisterPage.class);
                        startActivity(intent);
                    }
                    else{
                        Intent intent = new Intent(getApplicationContext(), RegisterPage.RegisterPage.class);
                        startActivity(intent);
                    }
                }

            }
        });

    }

}