package com.example.login_cs360jk;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Coverall {

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

    public class coverall extends AppCompatActivity implements overall {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_coverall);
        }
    }
}
