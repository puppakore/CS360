package com.example.login_cs360jk;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

    public class RegisterPage extends AppCompatActivity implements registerpage {
        private Button button;

        EditText username, password, confirm_password;
        Button submit;

        DBHelper MyDB;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_register_page);

            username = (EditText) findViewById(R.id.username);
            password = (EditText) findViewById(R.id.password);
            confirm_password = (EditText) findViewById(R.id.confirm_password);


            submit = (Button) findViewById(R.id.btn_submit);

            MyDB = new DBHelper(this);

            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String username = username.getText().toString();
                    String password = password.getText().toString();
                    String confirm_password = confirm_password.getText().toString();


                    if(username.equals("") || password.equals("") || confirm_password.equals(""))
                    {
                        Toast.makeText(RegisterPage.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Boolean result = MyDB.checkUsername(username);
                        if(result == false)
                        {
                            Boolean res = MyDB.insertData(username, password, confirm_password);
                            if(res==true)
                            {
                                Toast.makeText(RegisterPage.this,"Registration Succesful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), RegisterPage.class);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(RegisterPage.this,"Registration Failed!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(RegisterPage.this, "User already exists.\n Please Login", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), LoginPage.class);
                            startActivity(intent);
                        }

                    }
                }
            });
        }



    }

}
