package com.example.login_cs360jk;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DBHelper extends SQLiteOpenHelper{

    public static final String DBNAME = "people.db";

    public DBHelper(Context context){
        super(context, "people.db",  null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table person(username TEXT primary key, password TEXT, confirm_password TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1 ) {

        MyDB.execSQL("drop Table if exists person");

    }

    public Boolean insertData(String name, String dob, String aadhar_number, String city, String state, String pincode, String phone_number){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        String username = "";
        contentValues.put("username",username);
        String password = "";
        contentValues.put("password",password);
        String confirm_password = "";
        contentValues.put("confirm_password",confirm_password);

        long result = MyDB.insert("person",null,contentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public Boolean checkaadhar(String aadhar_number){

        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from person where aadhar_number = ?",new String[]{aadhar_number});
        if(cursor.getCount()>0)
        {
            return true;
        }
        else{
            return false;
        }
    }


    public Boolean checkUsername(String username) {
    }

    public Boolean insertData(String username, String password, String confirm_password) {
    }

    public Boolean new_register_here(String new_register_here) {
    }
}